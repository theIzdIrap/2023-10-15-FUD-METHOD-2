# FUD-METHOD-2


![dsad2312](https://github.com/theIzdIrap/FUD-METHOD-2/assets/62066592/35cd08ce-4714-42c3-ba8e-d6047d245dfe)
